<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

    public function data()
	{
        

        echo $data;

	}

	public function tampil()
	{
        $data['judul'] = "Halaman Tampil";
        $data['deskripsi'] =  "Operator adalah jenis pekerjaan fungsional di dalam suatu industri. Tugas utama dari operator lapangan adalah menjalankan suatu operasi";

        $this->load->view('tampil', $data);
	}
}