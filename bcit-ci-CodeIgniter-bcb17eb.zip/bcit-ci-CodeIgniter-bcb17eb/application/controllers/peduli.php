<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class peduli extends CI_Controller {

	public function index()
	{
      $data['query'] = $this->db->get('user')->result();

      $this->load->view('view_peduli', $data);
	}
}