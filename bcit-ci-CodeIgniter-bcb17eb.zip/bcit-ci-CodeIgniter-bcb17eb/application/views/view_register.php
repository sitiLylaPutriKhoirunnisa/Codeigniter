<html lang="en">
<head>
<title>Document</title>
<style>
    body {
        font-family: sans-serif;
        background-color: aqua;
    }
    .h1{
        text-align: center;
        font-weight: 300;
    }
    .login{
        width: 350px;
        background: white;
        margin: 80px auto;
        padding: 30px 20px;
    }
    label{
        font-size: 11pt;
    }
    .form_login{
        box-sizing: border-box;
        width: 100%;
        padding: 10px;
        font-size: 11pt;
        margin-bottom: 20px;
    }
    .tombol{
        background: rgb(22, 139, 130);
        color: white;
        font-size: 11pt;
        width: 100%;
        border: none;
        
        border-radius: 3px;
        padding: 10px 20px;
        margin-top: 20px ;
    }


</style>
</head>
<body>
    <div class="login">
    <form action="home" method="post">
        


        <h1>FORM REGISTER</h1>
        
        <label>
            NIS : 
            <input type="text" name="nis" id="" class="form_login" placeholder="nis">
        </label>
        <label>
            Nama : 
           <input type="text" name="nama" id="" class="form_login" placeholder="nama">
        </label>
        <label>
            KELAS:
            <input type="text" name="kelas" class="form_login" id="" placeholder="kelas">
        </label>
       
        <button type="submit" class="tombol">Register</button>
    </form>
</div>
</body>
</html>