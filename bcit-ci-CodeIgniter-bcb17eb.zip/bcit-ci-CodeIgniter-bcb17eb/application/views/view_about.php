<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
    <form action="home" method="post">
    <a>Profil SMK Mutu Cikampek
Tinggalkan Komentar / Profil SMK Mutu / Oleh smkmutu
SMK TI Muhammadiyah adalah salah satu dari beberapa sekolah menengah kejuruan swasta  yang mengemban
 misi yang sama dalam mencerdaskan anak bangsa. Dalam kiprahnya selama 16 tahun sejak berdirinya tahun 2003,
  SMK TI Muhammadiyah Cikampek melaksanakan tugasnya sebagai pelaksana pendidikan tingkat menengah dan selama
   kurun waktu tersebut SMK TI Muhammadiyah Cikampek melakukan pembenahan dalam semua bidang.

Untuk mengikuti pesatnya perkembangan industri dan teknologi pada saat ini, maka SMK TI Muhammadiyah Cikampek
  ikut menerapkan kebijakan dengan mempersiapkan diri dan berusaha meningkatkan mutu terutama di bidang teknologi
   industri tingkat menengah yang mampu menunjang pertumbuhan dan perkembangan teknologi industri dengan memanfaatkan
    serta mengembangkan segala potensi sumber daya  yang ada untuk digunakan dalam proses teknologi industri  baik secara
     teoritis maupun aplikatif, sehingga dapat dimanfaatkan dalam kehidupan bermasyarakat yang berjiwa wirausaha (enterpreneurship).

Seiring dengan perkembangan tersebut, SMK TI Muhammadiyah juga telah melakukan evaluasi diri guna mewujudkan kemandirian antara
 lain dengan mengkaji berbagai komponen, seperti kurikulum dan pembelajaran, administrasi dan manajemen, organisasi dan kelembagaan,
  sarana dan prasarana, ketenagaan, pembiayaan, dan pendanaan, peserta didik, peran serta masyarakat, serta lingkungan budaya,
   dan program keahlian.

Dalam mencapai sasaran yang telah diprogramkan dalam Rencana Strategis antara lain melalui penerapan Sistem Penjaminan
 Mutu Pendidikan yang akan dicanangkan bagi seluruh guru dan karyawan serta peserta didik SMK TI Muhammadiyah mulai tahun
  ini sebagai penerapan sekolah model dan sekolah rujukan. Dengan memanfaatkan semua potensi yang ada maka SMK TI Muhammadiyah
   diharapkan mampu menghasilkan lulusan dengan berbagai profil antara lain: Kompetensi umum mengacu kepada pendidikan nasional
    dan kecakapan hidup generik, sesuai tuntutan Undang Undang Sistem Pendidikan Nasional (UUSPN) pasal 3
     meliputi : Beriman dan bertaqwa, Berahklak mulia, sehat, cakap, kreatif, mandiri, demokratis dan bertanggung jawab.
      Sedangkan sesuai tuntutan dunia kerja adalah disiplin dan jujur. Kompetensi kejuruan adalah kompetensi yang mengacu pada
       SKKNI Teknologi Rekayasa dan Teknologi Informasi dan Komunikasi.</a>

</form>
</body>
</html>